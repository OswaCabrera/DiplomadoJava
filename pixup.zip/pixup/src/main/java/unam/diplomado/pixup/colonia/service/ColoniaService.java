package unam.diplomado.pixup.colonia.service;

import unam.diplomado.pixup.colonia.domain.Colonia;

public interface ColoniaService {

    Colonia actualizarColonia(Colonia colonia);

    Colonia crearColonia(Colonia colonia);
}
