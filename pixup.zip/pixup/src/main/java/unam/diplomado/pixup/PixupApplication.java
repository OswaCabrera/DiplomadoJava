package unam.diplomado.pixup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PixupApplication {

	public static void main(String[] args) {
		SpringApplication.run(PixupApplication.class, args);
	}

}
