package unam.diplomado.pixup.colonia.repository;

import org.springframework.data.repository.CrudRepository;
import unam.diplomado.pixup.colonia.domain.Municipio;

public interface MunicipioRepository extends CrudRepository<Municipio, Integer> {
}
