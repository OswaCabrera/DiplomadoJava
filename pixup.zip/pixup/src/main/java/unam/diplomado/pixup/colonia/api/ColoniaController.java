package unam.diplomado.pixup.colonia.api;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import unam.diplomado.pixup.colonia.domain.Colonia;
import unam.diplomado.pixup.colonia.domain.ColoniaAlreadyExistsException;
import unam.diplomado.pixup.colonia.domain.ColoniaNotFoundException;
import unam.diplomado.pixup.colonia.domain.MunicipioNotFoundException;
import unam.diplomado.pixup.colonia.repository.ColoniaRepository;
import unam.diplomado.pixup.colonia.service.ColoniaService;

import java.util.List;
import java.util.Optional;

@Slf4j
@RestController
public class ColoniaController implements ColoniaApi{

    @Autowired
    private ColoniaRepository coloniaRepository;

    @Autowired
    private ColoniaService coloniaService;

    @Override
    public ResponseEntity<Colonia> getColoniaById(Integer id) {
        Optional<Colonia> colonia = coloniaRepository.findById(id);
        if(colonia.isPresent()){
            return new ResponseEntity<>(colonia.get(), HttpStatus.OK);
        }
        return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
    }

    @Override
    public List<Colonia> getColoniasByCp(String cp) {
        return coloniaRepository.findByCp(cp);
    }

    @Override
    public Colonia createColonia(Colonia colonia) {
        return coloniaService.crearColonia(colonia);
    }

    @Override
    public ResponseEntity<Colonia> updateColonia(Integer id, Colonia colonia) {
        colonia.setId(id);
        try {
            Colonia coloniaActualizada = coloniaRepository.save(colonia);
            return new ResponseEntity<>(coloniaActualizada, HttpStatus.OK);
        }catch (ColoniaNotFoundException | MunicipioNotFoundException e){
            log.error("Error al actualizar la colonia con id: " + id, e);
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    @Override
    public void deleteColonia(Integer id) {
        coloniaRepository.deleteById(id);
    }


}