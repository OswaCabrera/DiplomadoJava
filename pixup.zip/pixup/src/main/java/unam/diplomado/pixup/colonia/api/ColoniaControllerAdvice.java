package unam.diplomado.pixup.colonia.api;

import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import unam.diplomado.pixup.colonia.domain.ColoniaAlreadyExistsException;
import unam.diplomado.pixup.colonia.domain.ColoniaNotFoundException;
import unam.diplomado.pixup.colonia.domain.MunicipioNotFoundException;

import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice("unam.diplomado.pixup.colonia.api")
public class ColoniaControllerAdvice {

    @ExceptionHandler(ColoniaAlreadyExistsException.class)
    @ResponseStatus(HttpStatus.CONFLICT)
    public String coloniaAlreadyExistsHandler(ColoniaAlreadyExistsException e) {
        return e.getMessage();
    }

    @ExceptionHandler(MunicipioNotFoundException.class)
    @ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
    private String municipioNotFoundHandler(MunicipioNotFoundException e) {
        return e.getMessage();
    }

    @ExceptionHandler(ColoniaNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    private String coloniaNotFoundHandler(ColoniaNotFoundException e) {
        return e.getMessage();
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    private Map<String, String> validatorHandler(MethodArgumentNotValidException e) {
        Map<String, String> errors = new HashMap<>();
        e.getBindingResult().getFieldErrors().forEach(
                error -> {
                    String nombreCampo = ((FieldError) error).getField();
                    String mensaje = error.getDefaultMessage();
                    errors.put(nombreCampo, mensaje);
                }
        );
        return errors;
    }


}
