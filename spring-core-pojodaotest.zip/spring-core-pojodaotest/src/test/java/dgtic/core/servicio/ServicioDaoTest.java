package dgtic.core.servicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest(classes = {ServicioDAOTest.class})

class ServicioDAOTest {
    @Test
    public void testUno(){
        String esperado="Spring";
        String actual="spring";
        assertEquals(esperado, actual,"Cadenas no iguales");
    }
}
