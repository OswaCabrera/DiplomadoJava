package dgtic.core.M9_P2_Oswaldo_Cabrera;

public class InfoTester {
    public static final String NOMBRE = """
            ╔══════════════════════════════════╗
            ║    Oswaldo Cabrera Pérez         ║
            ╚══════════════════════════════════╝
            """;
}