package dgtic.core.M9_P2_Oswaldo_Cabrera;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class M9P2OswaldoCabreraApplication {

	public static void main(String[] args) {
		SpringApplication.run(M9P2OswaldoCabreraApplication.class, args);
	}

}
