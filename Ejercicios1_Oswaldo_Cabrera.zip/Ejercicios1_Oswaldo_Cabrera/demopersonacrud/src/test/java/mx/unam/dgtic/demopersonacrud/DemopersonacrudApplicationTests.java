package mx.unam.dgtic.demopersonacrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemopersonacrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
