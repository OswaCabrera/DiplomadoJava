package mx.unam.dgtic.demopersonacrud.repositories;

import mx.unam.dgtic.demopersonacrud.modelo.Persona;
import org.springframework.data.repository.CrudRepository;

public interface PersonaRepository extends CrudRepository<Persona , Integer> {

}
