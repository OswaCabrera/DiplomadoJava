insert into alumnos values ("1A","Juan","Lopez","2001-01-01",1.78);
insert into alumnos values ("2A","Nadia","Perez","2001-01-10",1.56);
insert into alumnos values ("3B","Perla","Calles","2001-01-20",1.60);
insert into alumnos values ("4A","Carlos","Madero","2001-01-01",1.68);
insert into alumnos values ("5A","Javier","Amaro","2001-02-10",1.75);
insert into alumnos values ("6C","Jesus","Garcia","2001-03-20",1.65);
insert into alumnos values ("7B","Gema",null,"2001-03-20",1.53);
