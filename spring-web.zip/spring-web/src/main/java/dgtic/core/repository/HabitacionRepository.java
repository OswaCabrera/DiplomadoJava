package dgtic.core.repository;

import dgtic.core.model.entity.HabitacionEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HabitacionRepository extends JpaRepository<HabitacionEntity, Integer> {
}
