$.fn.datepicker.defaults.format = "dd/mm/yyyy";
$.fn.datepicker.defaults.language="es"