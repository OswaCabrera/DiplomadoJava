package unam.diplomado.pixup.disco.api;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RequestMapping(value = "/api/discos", produces = MediaType.APPLICATION_JSON_VALUE)
@CrossOrigin(origins = "*")
public interface DiscoApi {

    @PostMapping(path="alta", consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    DiscoResponseDTO altaDisco(@RequestBody @NotNull @Valid DiscoRequestDTO discoRequestDTO);
}
