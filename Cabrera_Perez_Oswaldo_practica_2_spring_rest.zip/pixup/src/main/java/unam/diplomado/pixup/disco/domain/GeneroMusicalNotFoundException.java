package unam.diplomado.pixup.disco.domain;

public class GeneroMusicalNotFoundException extends RuntimeException{

            public GeneroMusicalNotFoundException(Integer id) {
                super("No existe un genero musical registrado con id: " + id);
            }
}
