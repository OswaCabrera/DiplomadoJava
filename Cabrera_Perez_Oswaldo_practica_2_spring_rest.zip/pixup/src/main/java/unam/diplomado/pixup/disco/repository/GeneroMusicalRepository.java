package unam.diplomado.pixup.disco.repository;

import org.springframework.data.repository.CrudRepository;
import unam.diplomado.pixup.disco.domain.GeneroMusical;

public interface GeneroMusicalRepository extends CrudRepository<GeneroMusical, Integer> {
}
