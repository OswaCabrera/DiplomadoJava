package unam.diplomado.pixup.usuario.api;

import org.springframework.stereotype.Component;
import unam.diplomado.pixup.usuario.domain.Domicilio;
import unam.diplomado.pixup.usuario.domain.Usuario;

@Component
public class RegistroUsuarioMapper {

    public UsuarioResponseDTO toDto(Usuario usuario) {
        return new UsuarioResponseDTO(usuario.getId(), usuario.getEmail());
    }

    public Usuario toUsuario(UsuarioRequestDTO usuarioRequestDTO) {
        return new Usuario(
                null, usuarioRequestDTO.getNombre(), usuarioRequestDTO.getApellidoPaterno(),
                usuarioRequestDTO.getApellidoMaterno(), usuarioRequestDTO.getPassword(),
                usuarioRequestDTO.getEmail(), usuarioRequestDTO.getRfc());
    }

    public Domicilio toDomicilio(DomicilioDTO domicilioDTO) {
        return new Domicilio(
                domicilioDTO.getCalle(), domicilioDTO.getExterior(),
                domicilioDTO.getInterior(), domicilioDTO.getColonia());
    }

}
