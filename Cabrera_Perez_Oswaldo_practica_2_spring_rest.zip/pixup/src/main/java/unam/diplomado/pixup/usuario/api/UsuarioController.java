package unam.diplomado.pixup.usuario.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;
import unam.diplomado.pixup.usuario.domain.Domicilio;
import unam.diplomado.pixup.usuario.domain.Usuario;
import unam.diplomado.pixup.usuario.service.UsuarioService;

@RestController
public class UsuarioController implements UsuarioApi {

    @Autowired
    private RegistroUsuarioMapper mapper;
    @Autowired
    private UsuarioService usuarioService;

    @Override
    public UsuarioResponseDTO registrarUsuario(RegistroUsuarioDTO registroUsuarioDTO) {
        Usuario usuario = mapper.toUsuario(registroUsuarioDTO.getUsuario());
        Domicilio domicilio = mapper.toDomicilio(registroUsuarioDTO.getDomicilio());
        Usuario usuarioCreado = usuarioService.registrarUsuario(usuario, domicilio);
        return mapper.toDto(usuarioCreado);
    }

}
