package unam.diplomado.pixup.disco.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Disco {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String titulo;
    private Float precio;
    private Integer existencia;
    private Float descuento;
    @Column(name = "fecha_lanzamiento")
    private Date fechaLanzamiento;
    private String imagen;

    @ManyToOne(targetEntity = GeneroMusical.class)
    @JoinColumn(name = "id_genero_musical", nullable = false)
    private GeneroMusical generoMusical;

    @ManyToOne(targetEntity = Artista.class)
    @JoinColumn(name = "id_artista", nullable = false)
    private Artista artista;

    @ManyToOne(targetEntity = Disquera.class)
    @JoinColumn(name = "id_disquera", nullable = false)
    private Disquera disquera;

    public Disco(String titulo, Float precio, Integer existencia, Float descuento, Date fechaLanzamiento, String imagen, Integer idGeneroMusical, Integer idArtista, Integer idDisquera) {
        this.titulo = titulo;
        this.precio = precio;
        this.existencia = existencia;
        this.descuento = descuento;
        this.fechaLanzamiento = fechaLanzamiento;
        this.imagen = imagen;
        this.generoMusical = new GeneroMusical();
        this.generoMusical.setId(idGeneroMusical);
        this.artista = new Artista();
        this.artista.setId(idArtista);
        this.disquera = new Disquera();
        this.disquera.setId(idDisquera);
    }
}
