package unam.diplomado.pixup.disco.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import unam.diplomado.pixup.disco.domain.*;
import unam.diplomado.pixup.disco.repository.ArtistaRepository;
import unam.diplomado.pixup.disco.repository.DiscoRepository;
import unam.diplomado.pixup.disco.repository.DisqueraRepository;
import unam.diplomado.pixup.disco.repository.GeneroMusicalRepository;

import java.util.Optional;

@Service
public class DiscoServiceImpl implements DiscoService{

    @Autowired
    private DiscoRepository discoRepository;

    @Autowired
    private ArtistaRepository artistaRepository;

    @Autowired
    private DisqueraRepository disqueraRepository;

    @Autowired
    private GeneroMusicalRepository generoMusicalRepository;

    @Override
    public Disco altaDisco(Disco disco) {
        Optional<Disco> discoOptional = discoRepository.findByTituloAndArtistaNombre(disco.getTitulo(), disco.getArtista().getId());
        System.out.println("discoOptional: " + discoOptional);
        if(discoOptional.isPresent()){
            throw new DiscoAlreadyExistsException(disco.getTitulo(), disco.getArtista().getId());
        }
        Optional<Artista> artista = artistaRepository.findById(disco.getArtista().getId());
        if(artista.isEmpty()){
            throw new ArtistaNotFoundException(disco.getArtista().getId());
        }
        Optional<Disquera> disquera = disqueraRepository.findById(disco.getDisquera().getId());
        if(disquera.isEmpty()){
            throw new DisqueraNotFoundException(disco.getDisquera().getId());
        }
        Optional<GeneroMusical> generoMusical = generoMusicalRepository.findById(disco.getGeneroMusical().getId());
        if(generoMusical.isEmpty()){
            throw new GeneroMusicalNotFoundException(disco.getGeneroMusical().getId());
        }
        disco.setGeneroMusical(generoMusical.get());
        disco.setDisquera(disquera.get());
        disco.setArtista(artista.get());
        discoRepository.save(disco);
        return disco;
    }
}
