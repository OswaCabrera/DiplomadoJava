package unam.diplomado.pixup.disco.domain;

public class DiscoAlreadyExistsException extends RuntimeException{

        public DiscoAlreadyExistsException(String titulo, Integer artista) {
        super("Ya existe un disco registrado con titulo: " + titulo + " y artista: " + artista);
        }
}
