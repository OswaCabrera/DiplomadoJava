package unam.diplomado.pixup.disco.domain;

public class ArtistaNotFoundException extends RuntimeException{

        public ArtistaNotFoundException(Integer id) {
            super("No existe un artista registrado con id: " + id);
        }
}
