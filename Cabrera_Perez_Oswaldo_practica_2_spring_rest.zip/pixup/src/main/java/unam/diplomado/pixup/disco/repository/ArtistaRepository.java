package unam.diplomado.pixup.disco.repository;

import org.springframework.data.repository.CrudRepository;
import unam.diplomado.pixup.disco.domain.Artista;

public interface ArtistaRepository extends CrudRepository<Artista, Integer> {
}
