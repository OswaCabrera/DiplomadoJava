package unam.diplomado.pixup.disco.api;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.Date;

@Data
@AllArgsConstructor
public class DiscoRequestDTO {
    @NotBlank
    private String titulo;
    @NotNull
    private Float precio;
    private Integer existencia;
    private Float descuento;
    private Date fechaLanzamiento;
    private String imagen;
    @NotNull
    private Integer artista;
    @NotNull
    private Integer generoMusical;
    @NotNull
    private Integer disquera;
}
