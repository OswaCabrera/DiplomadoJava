package unam.diplomado.pixup.colonia.repository;

import org.springframework.data.repository.CrudRepository;
import unam.diplomado.pixup.colonia.domain.Colonia;

import java.util.List;
import java.util.Optional;

public interface ColoniaRepository
        extends CrudRepository<Colonia, Integer> {

    List<Colonia> findByCp(String cp);
    Optional<Colonia> findByCpAndNombre(String cp, String nombre);

    Colonia getColoniaById(Integer id);

}
