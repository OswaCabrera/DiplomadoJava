package unam.diplomado.pixup.usuario.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import unam.diplomado.pixup.colonia.domain.Colonia;
import unam.diplomado.pixup.colonia.domain.ColoniaNotFoundException;
import unam.diplomado.pixup.colonia.repository.ColoniaRepository;
import unam.diplomado.pixup.usuario.domain.Domicilio;
import unam.diplomado.pixup.usuario.domain.Usuario;
import unam.diplomado.pixup.usuario.domain.UsuarioAlreadyExistsException;
import unam.diplomado.pixup.usuario.repository.DomicilioRepository;
import unam.diplomado.pixup.usuario.repository.UsuarioRepository;

import java.util.Optional;

@Service
public class UsuarioServiceImpl implements UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;
    @Autowired
    private DomicilioRepository domicilioRepository;
    @Autowired
    private ColoniaRepository coloniaRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    @Transactional(propagation=Propagation.REQUIRED, timeout=5)
    public Usuario registrarUsuario(Usuario usuario, Domicilio domicilio) {
        Optional<Usuario> usuarioExistente =
                usuarioRepository.findByEmail(usuario.getEmail());
        if (usuarioExistente.isPresent()) {
            throw new UsuarioAlreadyExistsException(usuario.getEmail());
        }
        Optional<Colonia> coloniaExistente =
                coloniaRepository.findById(domicilio.getColonia().getId());
        if (coloniaExistente.isEmpty()) {
            throw new ColoniaNotFoundException(domicilio.getColonia().getId());
        }
        domicilio.setColonia(coloniaExistente.get());

        usuarioRepository.save(usuario);
        domicilio.setUsuario(usuario);
        domicilioRepository.save(domicilio);

        return usuario;
    }

    @Override
    public Usuario altaUsuario(Usuario usuario) {
        usuario.setPassword(
                passwordEncoder.encode(usuario.getPassword()));
        usuarioRepository.save(usuario);
        return usuario;
    }

}
