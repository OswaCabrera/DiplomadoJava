package unam.diplomado.pixup.disco.repository;

import org.springframework.data.repository.CrudRepository;
import unam.diplomado.pixup.disco.domain.Disquera;

public interface DisqueraRepository extends CrudRepository<Disquera, Integer> {
}
