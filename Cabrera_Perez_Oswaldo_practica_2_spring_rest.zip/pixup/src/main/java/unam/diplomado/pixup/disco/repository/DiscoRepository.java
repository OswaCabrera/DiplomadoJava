package unam.diplomado.pixup.disco.repository;

import jakarta.persistence.NamedNativeQuery;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import unam.diplomado.pixup.disco.domain.Disco;

import java.util.Optional;

public interface DiscoRepository extends CrudRepository<Disco, Integer> {
    //Create a query that finds a disco by titulo and artista using a join Disco with Artista
    //and return a Disco object
    @Query(value = "SELECT d FROM Disco d JOIN d.artista a WHERE d.titulo = ?1 AND a.id = ?2")
    Optional<Disco> findByTituloAndArtistaNombre(String titulo, Integer id_artista);
}
