package unam.diplomado.pixup.disco.api;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import unam.diplomado.pixup.disco.domain.ArtistaNotFoundException;
import unam.diplomado.pixup.disco.domain.DiscoAlreadyExistsException;
import unam.diplomado.pixup.disco.domain.DisqueraNotFoundException;
import unam.diplomado.pixup.disco.domain.GeneroMusicalNotFoundException;
import unam.diplomado.pixup.usuario.api.ErrorResponse;

@RestControllerAdvice("unam.diplomado.pixup.disco.api")
public class DiscosControllerAdvice {

    @ExceptionHandler(DiscoAlreadyExistsException.class)
    @ResponseStatus(HttpStatus.CONFLICT)
    private ErrorResponse discoAlreadyExistsHandler(DiscoAlreadyExistsException ex) {
        return new ErrorResponse(
                HttpStatus.CONFLICT.value(),
                "BUSINESS_RULE",
                ex.getMessage()
        );
    }

    @ExceptionHandler(ArtistaNotFoundException.class)
    @ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
    private ErrorResponse artistaNotFoundHandler(ArtistaNotFoundException ex) {
        return new ErrorResponse(
                HttpStatus.UNPROCESSABLE_ENTITY.value(),
                "DATA_INCONSISTENCY",
                ex.getMessage()
        );
    }

    @ExceptionHandler(DisqueraNotFoundException.class)
    @ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
    private ErrorResponse disqueraNotFoundHandler(DisqueraNotFoundException ex) {
        return new ErrorResponse(
                HttpStatus.UNPROCESSABLE_ENTITY.value(),
                "DATA_INCONSISTENCY",
                ex.getMessage()
        );
    }

    @ExceptionHandler(GeneroMusicalNotFoundException.class)
    @ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
    private ErrorResponse generoMusicalNotFoundHandler(GeneroMusicalNotFoundException ex) {
        return new ErrorResponse(
                HttpStatus.UNPROCESSABLE_ENTITY.value(),
                "DATA_INCONSISTENCY",
                ex.getMessage()
        );
    }

}
