package unam.diplomado.pixup.usuario.api;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import unam.diplomado.pixup.colonia.domain.ColoniaNotFoundException;
import unam.diplomado.pixup.usuario.domain.UsuarioAlreadyExistsException;

@RestControllerAdvice("unam.diplomado.pixup.usuario.api")
public class UsuarioControllerAdvice {

    @ExceptionHandler(UsuarioAlreadyExistsException.class)
    @ResponseStatus(HttpStatus.CONFLICT)
    private ErrorResponse usuarioAlreadyExistsHandler(UsuarioAlreadyExistsException ex) {
        return new ErrorResponse(
                HttpStatus.CONFLICT.value(),
                "BUSINESS_RULE",
                ex.getMessage()
        );
    }

    @ExceptionHandler(ColoniaNotFoundException.class)
    @ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
    private ErrorResponse coloniaNotFoundHandler(ColoniaNotFoundException ex) {
        return new ErrorResponse(
                HttpStatus.UNPROCESSABLE_ENTITY.value(),
                "DATA_INCONSISTENCY",
                ex.getMessage()
        );
    }
}
