package unam.diplomado.pixup.disco.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import unam.diplomado.pixup.disco.domain.Disco;

@Component
public class RegistroDiscoMapper {

    public Disco toDisco(DiscoRequestDTO discoRequestDTO) {
        return new Disco( discoRequestDTO.getTitulo(),
                discoRequestDTO.getPrecio(),
                discoRequestDTO.getExistencia(),
                discoRequestDTO.getDescuento(),
                discoRequestDTO.getFechaLanzamiento(),
                discoRequestDTO.getImagen(),
                discoRequestDTO.getGeneroMusical(),
                discoRequestDTO.getArtista(),
                discoRequestDTO.getDisquera());
    }

    public DiscoResponseDTO toDto(Disco disco) {
        return new DiscoResponseDTO(disco.getId(),
                disco.getTitulo(),
                disco.getArtista().getNombre(),
                disco.getDisquera().getNombre(),
                disco.getDisquera().getNombre());
    }

}
