package unam.diplomado.pixup.colonia.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import unam.diplomado.pixup.colonia.domain.*;
import unam.diplomado.pixup.colonia.repository.ColoniaRepository;
import unam.diplomado.pixup.colonia.repository.MunicipioRepository;

import java.util.Optional;

@Service
public class ColoniaServiceImpl implements ColoniaService{

    @Autowired
    private ColoniaRepository coloniaRepository;

    @Autowired
    private MunicipioRepository municipioRepository;

    @Override
    public Colonia actualizarColonia(Integer id, Colonia colonia) {
        Optional<Colonia> op = coloniaRepository.findById(id);
        if(op.isPresent()){
            Colonia coloniaActualizada = op.get();
            Optional<Municipio> municipioExistente = municipioRepository.findById(colonia.getMunicipio().getId());
            if(municipioExistente.isEmpty()){
                throw new MunicipioNotFoundException(colonia.getMunicipio().getId());
            }
            coloniaActualizada.setMunicipio(municipioExistente.get());
            coloniaActualizada.setNombre(colonia.getNombre());
            coloniaActualizada.setCp(colonia.getCp());
            return coloniaRepository.save(coloniaActualizada);
        }
        throw new ColoniaNotFoundException(id);
    }

    @Override
    public Colonia crearColonia(Colonia colonia) {
        Optional<Colonia> coloniaExistente =
                coloniaRepository.findByCpAndNombre(colonia.getCp(), colonia.getNombre());
        if (coloniaExistente.isEmpty()) {
            Optional<Municipio> municipioExistente =
                    municipioRepository.findById(colonia.getMunicipio().getId());
            if (municipioExistente.isEmpty()) {
                throw new MunicipioNotFoundException(colonia.getMunicipio().getId());
            }
            colonia.setMunicipio(municipioExistente.get());
            return coloniaRepository.save(colonia);
        }
        throw new ColoniaAlreadyExistsException(colonia.getCp(), colonia.getNombre());
    }

    @Override
    public Colonia getColoniaById(Integer id) {
        Optional<Colonia> colonia = coloniaRepository.findById(id);
        if(colonia.isPresent()){
            return colonia.get();
        }
        throw new ColoniaNotFoundException(id);
    }
}
