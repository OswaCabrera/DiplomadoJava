package unam.diplomado.pixup.usuario.api;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UsuarioResponseDTO {

    private Integer id;
    private String email;

}
