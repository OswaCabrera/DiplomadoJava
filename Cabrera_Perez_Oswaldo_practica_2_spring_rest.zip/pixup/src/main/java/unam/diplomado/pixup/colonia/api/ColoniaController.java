package unam.diplomado.pixup.colonia.api;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import unam.diplomado.pixup.colonia.domain.Colonia;
import unam.diplomado.pixup.colonia.domain.ColoniaAlreadyExistsException;
import unam.diplomado.pixup.colonia.domain.ColoniaNotFoundException;
import unam.diplomado.pixup.colonia.domain.MunicipioNotFoundException;
import unam.diplomado.pixup.colonia.repository.ColoniaRepository;
import unam.diplomado.pixup.colonia.service.ColoniaService;

import java.util.List;
import java.util.Optional;

@Slf4j
@RestController
public class ColoniaController implements ColoniaApi{

    @Autowired
    private ColoniaRepository coloniaRepository;

    @Autowired
    private ColoniaService coloniaService;

    @Override
    public Colonia getColoniaById(Integer id) {
        return coloniaService.getColoniaById(id);
    }

    @Override
    public List<Colonia> getColoniasByCp(String cp) {
        return coloniaRepository.findByCp(cp);
    }

    @Override
    public Colonia createColonia(Colonia colonia) {
        return coloniaService.crearColonia(colonia);
    }

    @Override
    public Colonia updateColonia(Integer id, Colonia colonia) {
        return coloniaService.actualizarColonia(id, colonia);
    }

    @Override
    public void deleteColonia(Integer id) {
        coloniaRepository.deleteById(id);
    }


}