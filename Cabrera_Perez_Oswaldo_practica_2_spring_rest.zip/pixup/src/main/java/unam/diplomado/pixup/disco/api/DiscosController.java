package unam.diplomado.pixup.disco.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;
import unam.diplomado.pixup.disco.domain.Disco;
import unam.diplomado.pixup.disco.service.DiscoService;

@RestController
public class DiscosController implements DiscoApi {

    @Autowired
    private RegistroDiscoMapper mapper;

    @Autowired
    private DiscoService discoService;

    @Override
    public DiscoResponseDTO altaDisco(DiscoRequestDTO discoRequestDTO) {
        Disco disco = mapper.toDisco(discoRequestDTO);
        Disco discoCreado = discoService.altaDisco(disco);
        return mapper.toDto(discoCreado);
    }
}
