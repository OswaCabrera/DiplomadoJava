package unam.diplomado.pixup.disco.api;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class DiscoResponseDTO {
    private Integer id;
    private String titulo;
    private String artista;
    private String generoMusical;
    private String disquera;
}
