package unam.diplomado.pixup.usuario.api;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class DomicilioDTO {

    private String calle;
    private String exterior;
    private String interior;
    @NotNull(message="Colonia es requerida")
    private Integer colonia;

}
