package unam.diplomado.pixup.web;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import unam.diplomado.pixup.usuario.domain.Usuario;

@Controller
@RequestMapping("/admin/orden")
public class OrdenController {

    @GetMapping
    public String ordenHome(Model model,
            @AuthenticationPrincipal Usuario usuario) {
        model.addAttribute("idUsuario", usuario.getId());
        model.addAttribute("emailUsuario", usuario.getEmail());
        return "orden";
    }

}
