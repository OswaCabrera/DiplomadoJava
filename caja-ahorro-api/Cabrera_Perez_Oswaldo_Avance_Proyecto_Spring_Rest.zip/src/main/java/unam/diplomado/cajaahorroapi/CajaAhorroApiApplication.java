package unam.diplomado.cajaahorroapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CajaAhorroApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CajaAhorroApiApplication.class, args);
	}

}
