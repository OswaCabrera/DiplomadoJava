package unam.diplomado.pixup.colonia.api;

import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import unam.diplomado.pixup.colonia.domain.ColoniaAlreadyExistsException;
import unam.diplomado.pixup.colonia.domain.ColoniaNotFoundException;
import unam.diplomado.pixup.colonia.domain.MunicipioNotFoundException;
import unam.diplomado.pixup.usuario.api.ErrorResponse;

import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice("unam.diplomado.pixup.colonia.api")
public class ColoniaControllerAdvice {

    @ExceptionHandler(ColoniaAlreadyExistsException.class)
    @ResponseStatus(HttpStatus.CONFLICT)
    public ErrorResponse coloniaAlreadyExistsHandler(ColoniaAlreadyExistsException e) {
        return new ErrorResponse(
                HttpStatus.CONFLICT.value(),
                "BUSSINESS_RULE",
                e.getMessage()
        );
    }

    @ExceptionHandler(MunicipioNotFoundException.class)
    @ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
    private ErrorResponse municipioNotFoundHandler(MunicipioNotFoundException e) {
        return new ErrorResponse(
                HttpStatus.UNPROCESSABLE_ENTITY.value(),
                "DATA_INCONSISTENCY",
                e.getMessage()
        );
    }

    @ExceptionHandler(ColoniaNotFoundException.class)
    @ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
    private ErrorResponse coloniaNotFoundHandler(ColoniaNotFoundException e) {
        return new ErrorResponse(
                HttpStatus.UNPROCESSABLE_ENTITY.value(),
                "DATA_INCONSISTENCY",
                e.getMessage()
        );
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    private Map<String, String> validatorHandler(MethodArgumentNotValidException e) {
        Map<String, String> errors = new HashMap<>();
        e.getBindingResult().getFieldErrors().forEach(
                error -> {
                    String nombreCampo = ((FieldError) error).getField();
                    String mensaje = error.getDefaultMessage();
                    errors.put(nombreCampo, mensaje);
                }
        );
        return errors;
    }


}
