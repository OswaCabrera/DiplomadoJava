package unam.diplomado.pixup.colonia.domain;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
public class Colonia {
    @Id
    @GeneratedValue(strategy =  GenerationType.IDENTITY)
    private Integer id;
    @NotBlank(message = "El nombre de la colonia no debe ser vacio")
    private String nombre;

    @Pattern(regexp = "^[0-9]{5}$", message = "El código postal debe tener 5 dígitos")
    private String cp;

    @ManyToOne(targetEntity = Municipio.class)
    @JoinColumn(name = "id_municipio", nullable = false)
    @NotNull(message = "El municipio no debe ser nulo")
    private Municipio municipio;

}
