package unam.diplomado.pixup.usuario.repository;

import org.springframework.data.repository.CrudRepository;
import unam.diplomado.pixup.usuario.domain.Domicilio;

public interface DomicilioRepository extends CrudRepository<Domicilio, Integer> {

}
