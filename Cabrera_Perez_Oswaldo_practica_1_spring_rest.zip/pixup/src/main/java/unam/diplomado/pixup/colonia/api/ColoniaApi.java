package unam.diplomado.pixup.colonia.api;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import org.apache.coyote.Response;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import unam.diplomado.pixup.colonia.domain.Colonia;

import java.util.List;

@RequestMapping(path="api/colonias", produces = MediaType.APPLICATION_JSON_VALUE)
@CrossOrigin(origins = "*")
public interface ColoniaApi {

    @GetMapping("{id}")
    Colonia getColoniaById(@PathVariable("id") Integer id);

    @PutMapping(path = "{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
    Colonia updateColonia(@PathVariable("id") Integer id, @RequestBody Colonia colonia);
    @GetMapping
    List<Colonia> getColoniasByCp(@RequestParam String cp);

    @PostMapping(consumes=MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    Colonia createColonia(@RequestBody @NotNull @Valid Colonia colonia);

    @DeleteMapping("{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    void deleteColonia(@PathVariable("id") Integer id);

}
