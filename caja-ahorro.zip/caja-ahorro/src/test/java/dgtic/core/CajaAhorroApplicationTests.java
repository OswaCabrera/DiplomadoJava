package dgtic.core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CajaAhorroApplicationTests {

	@Test
	void contextLoads() {
	}

}
