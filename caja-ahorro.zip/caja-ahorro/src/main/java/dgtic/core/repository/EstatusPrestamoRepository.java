package dgtic.core.repository;

import dgtic.core.model.entity.EstatusPrestamoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EstatusPrestamoRepository extends JpaRepository<EstatusPrestamoEntity,Integer> {
}
