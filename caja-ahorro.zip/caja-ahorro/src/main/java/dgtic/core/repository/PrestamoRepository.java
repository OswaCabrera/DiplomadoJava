package dgtic.core.repository;

import dgtic.core.model.entity.PrestamoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PrestamoRepository extends JpaRepository<PrestamoEntity,Integer> {
}
