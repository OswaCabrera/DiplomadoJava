package mx.unam.dgtic.alumnocrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlumnocrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlumnocrudApplication.class, args);
	}

}
