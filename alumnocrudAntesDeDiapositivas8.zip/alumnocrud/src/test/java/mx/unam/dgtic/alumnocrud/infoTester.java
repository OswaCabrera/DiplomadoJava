package mx.unam.dgtic.alumnocrud;

public class infoTester {
    public static final String NOMBRE = """
            ╔══════════════════════════════════╗
            ║    Oswaldo Cabrera Pérez         ║
            ╚══════════════════════════════════╝
            """;
}
